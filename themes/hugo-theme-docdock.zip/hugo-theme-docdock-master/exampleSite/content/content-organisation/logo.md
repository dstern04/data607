+++
title = "Logo placeholder"
description = ""
date = "2017-04-24T18:36:24+02:00"
Weight=1
+++

Create a `_header.md` page in content folder. Its content is what you get in the logo placeholder (top left of the screen).

{{%alert info%}}**Tip :** you can add a image, a combobox with links to other documentation....{{%/alert%}}

{{%alert info%}}**Tip 2 :** look at [ extra static menu]({{%relref "extramenu.md"%}}) if you want to add links to other website in this sidebar{{%/alert%}}